#include "point2D.h"

point2D::point2D(double x, double y) :x_(x), y_(y) {}

point2D::point2D() :x_(0.0), y_(0.0) {}

vector2D point2D::operator-(const point2D& p) const
{
	return vector2D(x_ - p.x_, y_ - p.y_);
}

point2D point2D::operator+(const vector2D& v) const
{
	return point2D(x_ + v.x(), y_ + v.y());
}

point2D point2D::operator-(const vector2D& v) const
{
	return point2D(x_ - v.x(), y_ - v.y());
}

void point2D::draw()
{
	printf("%f\t%f\n", x_, y_);
}
