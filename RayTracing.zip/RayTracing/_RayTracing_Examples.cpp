
#include <iostream>
#include "ray.h"

//Developed classes allow to perform a 2D ray tracing simulation
//defining reflecting surfaces (2D lines), and absorbing volumes (2D areas)

//First, a reactor must be declared
//Currently, only CircleReactor (a tube) and SegmentsReactor (a convex angles prism) can be declared
//Circle reactors constructor requires a center (Point2D) and a radius (double)
//Segments reactors have an empty constructor, and include several functions to define their geometry:
//    addPoint(point2D)       to define the consecutive points of the prism profile
//    close()                 once all the points are defined, to create the segments and calculate the profile area

//Second, a simulation must be declared
//It is the main class, storing all the geometry and optical properties
//Simulation constructor needs a reactor, an optical density, and the number of rays that will be used
//Once constructed, several functions can be used to complete the geometry definition:
//    addReactor(Reactor *)   It uses a pointer, and not a Reactor instance, to allow polymorphism in reactors functions
//                            The memomry address of a reactor created in the main function can be passed using "&":
//                            CircleReactor r2(point2D(0.0,2.0), 0.7);  case.addReactor(&r2);
//    addCollector(Collector, double) The class collector and its constructors are described below
//                            The second parameter is the reflectance of the collector (0 - 1).
//                            If a given geometry needs different reflectances at different locations,
//                              it needs to be declared as several collectors.

//A collector has an empty constructor, and points will be added until the geometry is fully defined
//    addPoint(point2D)       Works like addPoint in Segments Reactor
//    close()                 Works like close in Segments Reactor (for closed collectors)
//    createSegments()        Equivalent to close, but for opened collectors (CPCs, PTCs...)
//  As most collectors are opened collectors, close() function is called when they are added to the simulation

//Once defined the case geometry, a radiation source must be declared.
// Simulation class offer a simple function to generate parallel beams from the geometric limits of the geometry
//  generateBoxBeams(vector2D) It produces a list of beams (vector<beam>)
// Alternatively, the user can produce a beam or a list of beams, to define other types of sources
// A beam2D constructor needs an origin (point2D), and a direction(vector2D)
// Example code to produce a punctual isotropic source:
//      std::vector<beam2D> punctualSource;
//      for(int i = 0; i < 360; i++)
//        punctualSource.push_back(beam2D(point2D(1.5,2.0), vector2D(cos(M_PI*i/180.0),sin(M_PI*i/180.0))));

//Finally, a list of rays will be declared, using the source (list of beams) and the simulation to construct them.
//The ray constructor, receiving a beam, and a reference to a simulation, traces the ray travel during construction
//Thus, once all the rays are constructed, the ray tracing simulation has finished

//Getting results from the simulation:

//Numerical results: simulation class offers a calculate function, that require the output values to be passed by reference:
//  calculate(int nRays, double& DCF, double& DCF_flux, double& distrib)
//  nRays is the number of rays used to perform the simulation
//  DCF is the Dynamical Concentration Factor, a relation between emitted radiation and available incident radiation
//  DCF_flux is the Dynamical Concentration Factor based on flux, a relation betweeen emitted and absorbed energy
//  distrib is a measure of the homogeneity of incident radiation inside the reactors
//  distrib 0 would mean total homogeneity, with higher values as heterogeneity increases
//  It is designed to be used always comparing designs, with arbitrary units for heterogeneity
//  The class also offers a clear() function to avoid redefining the geometry of the case to perform a new simulation
//  Allowing to quickly modify the source, or the number of rays

//Graphical results: Both the geometry and the rays can produce segments to draw them in any external software
// Using the draw() function, available in collectors, reactors, and rays, the simulation will output to console a list
// of 2D points, with the first column for x coordinates and the second one for y coordinates.

//Some example codes (including all the ones used in the article) are presented below, but intended to be used as a base:




point2D point2D::nullPoint = point2D(0.0, 0.0);
int reactorN1();
int reactorN2();
int reactorN3();
int casoRaro();
int probarReactor();
int nReactors1();
int probarFresnel();
int estudiarSimpl3();
int raceway();
int TFGDavidCarac(int argc, char** argv)
{
    /*rayTracing draw[angulo incidencia min][angulo incidencia max][nº Incrementos][nRayos][radio_reactor][xReac][yReac][absorptionCoeff][nColectores]
            para cada colector : [coef Ref] [nº points]
                para cada point : [xpoint] [ypoint]*/

    if (argc < 11)
    {
        printf("Error. 1");
        return -1;
    }
    int nRayos, nColectores, nIncrem;
    double incidenciaMin, incidenciaMax, radioReactor, xReac, yReac, absorptionCoeff;
    incidenciaMin = atof(argv[2]);
    incidenciaMax = atof(argv[3]);
    nIncrem = atoi(argv[4]);
    nRayos = atoi(argv[5]);
    radioReactor = atof(argv[6]);
    xReac = atof(argv[7]);
    yReac = atof(argv[8]);
    absorptionCoeff = atof(argv[9]);
    nColectores = atoi(argv[10]);
    CircleReactor reactor(point2D(xReac, yReac), radioReactor);
    double DO = absorptionCoeff * (2.0 * radioReactor);
    simulation simulacion(&reactor, DO, nRayos);
    int argsAleer = 11;
    for (int i = 0; i < nColectores; i++)
    {
        collector c;
        argsAleer += 2;
        if (argc < argsAleer)
        {
            printf("Error. 2");
            return -1;
        }
        double ref = atof(argv[argsAleer - 2]);
        int npoints = atoi(argv[argsAleer - 1]);
        if (argc < (argsAleer + npoints * 2))
        {
            printf("Error. 3, %d", argsAleer + npoints * 2);
            return -1;
        }
        for (int j = 0; j < npoints; j++)
        {
            c.addpoint(point2D(atof(argv[argsAleer]), atof(argv[argsAleer + 1])));
            argsAleer += 2;
        }
        simulacion.addCollector(c, ref);
    }
    double deltaIncidencia = (incidenciaMax - incidenciaMin) / nIncrem;
    std::vector<double> incidencias, DCFs, DCFs_flujo;
    for (int incidenciaI = 0; incidenciaI < nIncrem; incidenciaI++)
    {
        double incidencia = incidenciaMin + incidenciaI * deltaIncidencia;
        double alfa = incidencia * M_PI / 180.0;
        std::vector<beam2D> inicios = simulacion.generateBoxBeams(vector2D(-sin(alfa), -cos(alfa)));
        std::vector<ray> resultados;
        for (int i = 1; i < inicios.size(); i++)
        {
            ray r(inicios[i], simulacion);
        }
        double DCF, DCF_flux, distrib;
        simulacion.calculate(nRayos, DCF, DCF_flux, distrib);
        incidencias.push_back(incidencia);
        DCFs.push_back(DCF);
        DCFs_flujo.push_back(DCF_flux);
        simulacion.clear();
    }
    printf("{\"incidencia\": [ %f", incidencias[0]);
    for (int i = 1; i < nIncrem; i++)
        printf(", %f", incidencias[i]);
    printf("], \"DCF\": [ %f", DCFs[0]);
    for (int i = 1; i < nIncrem; i++)
        printf(", %f", DCFs[i]);
    printf("], \"DCF_q\": [ %f", DCFs_flujo[0]);
    for (int i = 1; i < nIncrem; i++)
        printf(", %f", DCFs_flujo[i]);
    printf("] }");
    return 0;
}
int TFGDavidDraw(int argc, char** argv)
{
    /*rayTracing draw[angulo incidencia][nRayos][radio_reactor][xReac][yReac][absorptionCoeff][nColectores]
        para cada colector : [coef Ref] [nº points] 
            para cada point : [xpoint] [ypoint]*/
    if (argc < 9)
    {
        printf("Error. 1");
        return -1;
    }
    int nRayos, nColectores;
    double incidencia, radioReactor, xReac, yReac, absorptionCoeff;
    incidencia = atof(argv[2]); 
    nRayos = atoi(argv[3]);
    radioReactor = atof(argv[4]);
    xReac = atof(argv[5]);
    yReac = atof(argv[6]);
    absorptionCoeff = atof(argv[7]);
    nColectores = atoi(argv[8]);
    CircleReactor reactor(point2D(xReac, yReac), radioReactor);
    double DO = absorptionCoeff * (2.0 * radioReactor);
    simulation simulacion(&reactor, DO, nRayos);
    int argsAleer = 9;
    for (int i = 0; i < nColectores; i++)
    {
        collector c;
        argsAleer += 2;
        if (argc < argsAleer)
        {
            printf("Error. 2");
            return -1;
        }
        double ref = atof(argv[argsAleer - 2]);
        int npoints = atoi(argv[argsAleer - 1]);
        if (argc < (argsAleer + npoints * 2))
        {
            printf("Error. 3, %d", argsAleer + npoints * 2);
            return -1;
        }
        for (int j = 0; j < npoints; j++)
        {
            c.addpoint(point2D(atof(argv[argsAleer]), atof(argv[argsAleer + 1])));
            argsAleer += 2;
        }
        simulacion.addCollector(c, ref);
    }
    double alfa = incidencia * M_PI / 180.0;
    std::vector<beam2D> inicios = simulacion.generateBoxBeams(vector2D(-sin(alfa), -cos(alfa)));
    std::vector<ray> resultados;
    //{"nRayos": 200, "startingIndex": [0, 1,...], "rayosX":[x, y, ...], "rayosY":[x, y, ...]}
    printf("{\"nRayos\": %d", nRayos);
    printf(", \"startingIndex\": [");
    size_t startingIndex = 0;
    ray r(inicios[0], simulacion);
    printf("%zu", startingIndex);
    startingIndex += r.size();
    resultados.push_back(r);
    for (int i = 1; i < inicios.size(); i++)
    {
        ray r(inicios[i], simulacion);
        printf(", %zu", startingIndex);
        startingIndex += r.size();
        resultados.push_back(r);
    }
    printf("]");
    printf(", \"rayosX\": [");
    resultados[0].drawX();
    for (int i = 1; i < resultados.size(); i++)
    {
        printf(", ");
        resultados[i].drawX();
    }
    printf("]");
    printf(", \"rayosY\": [");
    resultados[0].drawY();
    for (int i = 1; i < resultados.size(); i++)
    {
        printf(", ");
        resultados[i].drawY();
    }
    printf("]}");
    return 0;
}
int TFGDavid(int argc, char** argv)
{
    if (argc < 2)
    {
        printf("Error. Pocos argumentos.\n");
        return -1;
    }
    if (strcmp("draw", argv[1]) == 0)
        return TFGDavidDraw(argc, argv);
    return TFGDavidCarac(argc,argv);
}
int ReactorPeru()
{
    //double w = 1.0; //a mano
    double r = 0.1;
    double DO = 0.0;
    int nRayos = 200;
    double ref = 0.9;
    CircleReactor reactor(point2D(0.0, 0.0), r);
    //double radAnual[] = { 196.657868900729,2042.42204064381,2571.34019452679,4069.30649145157,4699.30089335946,6255.73482692857,6953.06731376499,8327.74860273696,9139.4132258562,10139.4317473625,10928.0761958307,11611.7715263207,12492.6928870888,13607.5641976677,14885.1995145651,15990.4644114071,16880.0813477847,16934.4434112228,18525.7827512448,19235.0030518472,20880.9683998356,21358.2832455005,22798.8570992045,23224.659101046,24723.107489407,24875.797933516,27431.466458308,27228.8090057048,29700.5565480897,29314.4449245496,32390.6149008952,32743.5729214592,35987.0287748261,37645.1623728292,43007.0582078469,46210.1461332337,44137.839852894,42148.1383233711,41080.914020232,39757.1926202868,39626.7685804547,39815.2467718908,39511.6375509642,39479.2715830695,39889.9607947261,40060.6492990159,39495.7292672917,38979.3296141183,39401.0883665235,40168.3458364274,40313.729999282,39364.6748592288,38969.2334331587,40702.4099193754,40205.5236964893,39011.4690579516,39653.8979684592,41132.0787918341,39348.0844111658,38695.793927539,40948.435524181,38826.1637196988,38114.4125246075,40056.8273017744,38261.5060008979,38342.6134623771,38658.9268133163,37157.0873484539,38560.1523967957,37240.4631543016,35805.344392621,38320.6045773045,35528.8122199963,34000.3556340606,34843.6377499418,32917.5862283941,34749.2112570918,31859.2759231747,30074.6216728214,30629.3354168807,28004.5718941856,28501.503650275,25522.8848753189,22892.4125583581,22859.3679648083,19351.1312354771,17832.3572837058,15315.8327298161,14631.4621476638,14631.4621476638,28645.4589113104,28645.4589113104,30083.4502053877,30083.4502053877,37713.5727435478,37713.5727435478,43787.8795181712,43787.8795181712,48624.5363995655,48624.5363995655,52228.8757917963,52228.8757917963,55146.0598194137,55146.0598194137,57420.34370968,57420.34370968,59190.8603204945,59190.8603204945,60560.5220524545,62938.6737090459,61606.4783975153,68171.7936869411,62387.1819403479,65284.8453827752,62947.8572896725,65504.5687764505,63323.7056443574,65287.956627388,63542.7720461175,64661.1062801697,63627.5690514874,64744.6625906668,63810.3120628512,64925.8614723657,63680.7813276469,64794.5580619298,63462.6444396428,64574.3698252296,63396.6781910634,64506.1474677358,63033.6671314174,63216.3090555778,62843.6173092089,63941.8741064318,62591.2822258448,63219.0859794613,62291.9176342568,62911.88226005,61721.7479004413,62569.5054666111,61352.2865359429,61723.0431215327,61179.8546765566,62256.8241813984,57647.8944073818,61329.6827278805,57159.8838208004,60860.1776214587,66598.6647921251,61081.639240261,62919.3557775608,60070.498154578,61417.4445358576,60260.1829175837,61346.2465969705,59926.215500686,61004.6031919346,63053.2136521259,60911.5744570468,68127.9832630848,59790.3992396991,64294.4045987728,69061.1902905361,62428.8396574195,67935.3714024739,75420.3785383157,76459.2949006364,87175.7415800065,99121.987559193,86188.1876073639,63550.094462619,50428.8052994202,41287.3485051992,34641.889014874,28004.3155924074,21368.7333833602,16709.0005174637,12036.9537929797,7114.14349177467,2204.24691036251,1462.30422757913 };
    double radAnual[] = { 196.321039885665,687.092356945791,1055.72218918147,1472.82765747014,1837.71058795681,2276.81506648858,2640.56084404729,2975.83465288487,3387.53430772604,3815.99538113235,4170.91677496543,4459.54400707354,4796.55696068573,5109.22543329085,5709.69575855957,6072.51086893802,6294.91933230108,6662.30835706115,7276.84572874427,7577.39165453125,8174.96299381104,8748.43133773403,9103.36586579936,9583.08137767763,9962.05654389951,10566.0715430076,11462.5461262594,11907.9533028142,12735.6266234902,13277.1776332185,14465.7022461767,15492.1012143944,16974.6285751148,18782.6372123088,22866.8099232717,25555.8176229109,22908.6178794447,20223.549141371,18501.2309018015,16869.066671291,16305.4305348143,15964.0709610888,15421.4583449491,15015.1833769172,14888.0188820625,14667.8669223869,14012.1322164773,13265.3730404974,13234.0381062952,13501.1709748586,13512.1243478935,12532.5234488827,11993.639084267,12857.9252821765,12488.654466743,11590.6463448168,11817.8986834648,12534.3468151965,11236.5449063751,10733.9274037013,12026.0675350183,10672.5494773631,10218.077939389,11156.4502856382,10128.3662787384,10210.0128116416,10243.8841084936,9484.16029669521,10201.1809285142,9497.35785879583,8826.51530635567,10115.3140989389,8682.53766973879,8091.11918651606,8549.70203932403,7759.45686451977,8697.38660872704,7501.14488172393,6839.8808236619,7283.11562608316,6365.56437590927,6851.00633968096,5832.42364812837,4936.68585525506,5437.02193374638,4132.48047796968,4274.27011603378,3236.75130520376,3071.7416547727,3071.7416547727,2864.54589113103,2864.54589113103,3008.34502053877,3008.34502053877,3771.35727435477,3771.35727435477,4378.78795181713,4378.78795181713,4862.45363995655,4862.45363995655,5222.88757917963,5222.88757917963,5514.60598194137,5514.60598194137,5742.034370968,5742.034370968,5919.08603204945,5919.08603204945,6056.05220524544,6293.86737090458,6160.64783975153,6817.17936869411,6238.71819403479,6528.48453827753,6294.78572896726,6550.45687764506,6332.37056443574,6528.7956627388,6354.27720461175,6466.11062801697,6362.75690514874,6474.46625906669,6381.03120628512,6492.58614723657,6368.0781327647,6479.45580619298,6346.26444396428,6457.43698252296,6339.66781910634,6450.61474677358,6303.36671314174,6321.63090555778,6284.36173092089,6394.18741064318,6259.12822258447,6321.90859794613,6229.19176342567,6291.188226005,6172.17479004413,6256.95054666112,6135.22865359429,6172.30431215327,6117.98546765566,6225.68241813984,5764.78944073817,6132.96827278805,5715.98838208004,6086.01776214586,6659.86647921251,6108.16392402609,6291.93557775608,6007.0498154578,6141.74445358576,6026.01829175838,6134.62465969705,5992.6215500686,6100.46031919346,6305.32136521259,6091.15744570468,6812.79832630848,5979.03992396991,6429.44045987728,6906.11902905361,6242.88396574195,6793.53714024739,7542.03785383156,7645.92949006364,8717.57415800065,9912.1987559193,8618.81876073639,6355.0094462619,5042.88052994202,4128.73485051992,3464.1889014874,2800.43155924074,2136.87333833602,1670.90005174637,1203.69537929797,711.414349177467,220.424691036251,146.230422757913 };
    double DCF, DCF_flux, distrib;
    double maxAcum = 0.0;
    for (int fI = 20; fI < 101; fI++)
    {
        for (int fB = 0; fB < 100; fB++)
        {
            simulation simulacion(&reactor, DO, nRayos);
            collector tramo;
            double f = 0.05 * r * fI;
            double h = f + r;
            double w = 1.0;// 0.01 * fI;
            double b = 0.01 * w * fB;
            point2D p1(-w / 2.0, h - f);
            point2D p2(-b / 2.0, -f);
            point2D p3(b / 2.0, -f);
            point2D p4(w / 2.0, h - f);
            //Calcular si choca p1-p2 con circulo
            vector2D vTramo = p2 - p1;
            vTramo = vTramo / vTramo.mag();
            vector2D v1R = point2D(0, 0) - p1;
            vector2D sombra = vTramo * (v1R & vTramo);
            vTramo = v1R - sombra;
            if (vTramo.mag() < r)
                continue;
            tramo.addpoint(p1);
            tramo.addpoint(p2);
            tramo.addpoint(p3);
            tramo.addpoint(p4);
            simulacion.addCollector(tramo, ref);
            double acum = 0.0;
            for (int index = 0; index < 181; index++)
            {
                double alfa = M_PI * (index-90) / 180.0;
                std::vector<beam2D> inicios = simulacion.generateBoxBeams(vector2D(-sin(alfa), -cos(alfa)));
                for (int i = 0; i < inicios.size(); i++)
                {
                    ray r(inicios[i], simulacion);
                }
                simulacion.calculate(nRayos, DCF, DCF_flux, distrib);
                //printf("%d\t%f\t%f\t%f\n", index, DCF, DCF_flux, distrib);
                simulacion.clear();
                acum += DCF * (radAnual[index]+7.76e3);
            }
            if (acum > maxAcum)
            {
                printf("%d,%d:%g\n", fI, fB, acum/ 2.79E+06);
                maxAcum = acum;
            }
        }
    }
    return 0;
}
int main(int argc, char ** argv)
{
    //return estudiarSimpl3();
    //return probarReactor();
    //return TFGDavid(argc, argv);
    //return ReactorPeru();
char** nullArgv = nullptr;
    return TFGDavidCarac(0, nullArgv);
}
int nReactors1()
{
    double DO = 0.0;
    int nRayos = 500;
    double ref = 0.9;
    int nReactors = 7;
    double radioE = 0.103;
    double margen = -5.0*radioE;
    CircleReactor reactor(point2D(0.0, 0.0), 0.097);
    simulation simulacion(&reactor, DO, nRayos);
    collector c;
    for (int i = 1; i < nReactors; i++)
        simulacion.addReactor(new CircleReactor(point2D(0.206*i,0.0), 0.097));
    c.addpoint(point2D(-margen, -0.103));
    c.addpoint(point2D(0.206*nReactors-0.206+margen, -0.103));
    simulacion.addCollector(c, ref);
    for (int theta = 0; theta < 90; theta++)
    {
        simulacion.clear();
        double alfa = (double)theta * M_PI / 180.0;
        std::vector<beam2D> inicios = simulacion.generateBoxBeams(vector2D(-sin(alfa), -cos(alfa)));
        for (int i = 0; i < inicios.size(); i++)
        {
            ray r(inicios[i], simulacion);
        }
        double DCF, DCF_flux, distrib;
        simulacion.calculate(nRayos, DCF, DCF_flux, distrib);
        printf("%d\t%f\t%f\t%f\n", theta, DCF, DCF_flux, distrib);
    }
    return 0;
}
int reactorN1()
{
    FILE* readFile, * outputFile;
    fopen_s(&readFile, "1input 2.txt", "r");
    fopen_s(&outputFile, "1output 2.txt", "w");
    float f, h, w;
    h = 0.0;//para que tengan esta todos
    int theta;
    double DO = 0.0;
    int nRayos = 500;
    double ref = 0.9;
    if (readFile == NULL) return 1;
    if (outputFile == NULL) return 1;
    int leidos = 4;
    while (leidos != EOF)
    {
        leidos = fscanf_s(readFile, "%d", &theta);
        leidos = fscanf_s(readFile, "%f", &f);
        leidos = fscanf_s(readFile, "%f", &w);
        CircleReactor reactor(point2D(0.0, 0.0), 0.013);
        double alfa = ((double)theta - 1.0) * M_PI / 180.0;
        simulation simulacion(&reactor, DO, nRayos);
        collector c;
        c.addpoint(point2D(-w / 2.0, - f));
        c.addpoint(point2D(w / 2.0, - f));
        simulacion.addCollector(c, ref);
        std::vector<beam2D> inicios = simulacion.generateBoxBeams(vector2D(-sin(alfa), -cos(alfa)));
        for (int i = 0; i < inicios.size(); i++)
        {
            ray r(inicios[i], simulacion);
        }
        double DCF, DCF_flux, distrib;
        simulacion.calculate(nRayos, DCF, DCF_flux, distrib);
        fprintf(outputFile, "%d\t%f\t%f\t%f\t%f\n", theta - 1, f, h, w, DCF);
    }
    fclose(readFile);
    fclose(outputFile);
    return 0;
}
int reactorN2()
{
    FILE* readFile, * outputFile;
    fopen_s(&readFile, "2input 2.txt", "r");
    fopen_s(&outputFile, "2output 2.txt", "w");
    float f, h, w;
    int theta;
    double DO = 0.0;
    int nRayos = 500;
    double ref = 0.9;
    if (readFile == NULL) return 1;
    if (outputFile == NULL) return 1;
    
    int leidos = 4;
    while (leidos != EOF)
    {
        leidos = fscanf_s(readFile, "%d", &theta);
        leidos = fscanf_s(readFile, "%f", &f);
        leidos = fscanf_s(readFile, "%f",  &h);
        leidos = fscanf_s(readFile, "%f", &w);
        CircleReactor reactor(point2D(0.0, 0.0), 0.013);
        double alfa = ((double)theta-1.0) * M_PI / 180.0;
        simulation simulacion(&reactor, DO, nRayos);
        collector c;
        c.addpoint(point2D(-w/2.0, h-f));
        c.addpoint(point2D(0.0, -f));
        c.addpoint(point2D(w/2.0, h-f));
        simulacion.addCollector(c, ref);
        std::vector<beam2D> inicios = simulacion.generateBoxBeams(vector2D(-sin(alfa), -cos(alfa)));
        for (int i = 0; i < inicios.size(); i++)
        {
            ray r(inicios[i], simulacion);
        }
        double DCF, DCF_flux, distrib;
        simulacion.calculate(nRayos, DCF, DCF_flux, distrib);
        fprintf(outputFile, "%d\t%f\t%f\t%f\t%f\n", theta-1, f, h, w, DCF);
    }
    fclose(readFile);
    fclose(outputFile);
    return 0;
}
int reactorN3()
{
    FILE* readFile, * outputFile;
    fopen_s(&readFile, "3input 2.txt", "r");
    fopen_s(&outputFile, "3output 2.txt", "w");
    float f, h, w, b;
    int theta;
    double DO = 0.0;
    int nRayos = 500;
    double ref = 0.9;
    if (readFile == NULL) return 1;
    if (outputFile == NULL) return 1;

    int leidos = 4;
    while (leidos != EOF)
    {
        leidos = fscanf_s(readFile, "%d", &theta);
        leidos = fscanf_s(readFile, "%f", &b);
        leidos = fscanf_s(readFile, "%f", &f);
        leidos = fscanf_s(readFile, "%f", &h);
        leidos = fscanf_s(readFile, "%f", &w);
        CircleReactor reactor(point2D(0.0, 0.0), 0.013);
        double alfa = ((double)theta - 1.0) * M_PI / 180.0;
        simulation simulacion(&reactor, DO, nRayos);
        collector c;
        c.addpoint(point2D(-w / 2.0, h - f));
        c.addpoint(point2D(-b/2.0, -f));
        c.addpoint(point2D(b/2.0, -f));
        c.addpoint(point2D(w / 2.0, h - f));
        simulacion.addCollector(c, ref);
        std::vector<beam2D> inicios = simulacion.generateBoxBeams(vector2D(-sin(alfa), -cos(alfa)));
        for (int i = 0; i < inicios.size(); i++)
        {
            ray r(inicios[i], simulacion);
        }
        double DCF, DCF_flux, distrib;
        simulacion.calculate(nRayos, DCF, DCF_flux, distrib);
        fprintf(outputFile, "%d\t%f\t%f\t%f\t%f\t%f\n", theta - 1, b, f, h, w, DCF);
    }
    fclose(readFile);
    fclose(outputFile);
    return 0;
}
int casoRaro()
{
    FILE* rayos;
    fopen_s(&rayos, "rayos.txt", "w");
    if (rayos == NULL) return 1;
    double DO = 0.0;
    int nRayos = 20;
    double ref = 0.9;
    int theta = 1;
    CircleReactor reactor(point2D(0.0, 0.0), 0.013);
    double alfa = (double)theta * M_PI / 180.0;
    simulation simulacion(&reactor, DO, nRayos);
    collector c;
    float f = 0.0384f;
    float h = 0.096f;
    float w = 0.096f;
    c.addpoint(point2D(-w / 2.0, h - f));
    c.addpoint(point2D(0.0, -f));
    c.addpoint(point2D(w / 2.0, h - f));
    simulacion.addCollector(c, ref);
    std::vector<beam2D> inicios = simulacion.generateBoxBeams(vector2D(-sin(alfa), -cos(alfa)));
    for (int i = 0; i < inicios.size(); i++)
    {
        ray r(inicios[i], simulacion);
        r.draw(rayos);
        fprintf(rayos, "\n");
    }
    double DCF, DCF_flux, distrib;
    simulacion.calculate(nRayos, DCF, DCF_flux, distrib);
    fclose(rayos);
    return 0;
}
int probarReactor()
{
    for (double incidencia = 0.0; incidencia < 90.0; incidencia += 1.0)
    {
        CircleReactor reactor(point2D(0.0, 0.0), 0.013);
        double DO = 0.0;// / sin(azimuth);
        int nRayos = 500;
        double ref = 0.9;
        simulation simulacion(&reactor, DO, nRayos);
        collector c;
        double alfa = incidencia * M_PI / 180.0;
        float f = 0.0288f;
        float h = 0.032f;
        float w = 0.0448f;
        float b = 0.0f;
        //Caso 1:
        //c.addpoint(point2D(-0.016, -0.016));
        //c.addpoint(point2D(0.016, -0.016));

        //Caso 2:
        //c.addpoint(point2D(-0.0192, 0));
        //c.addpoint(point2D(0, -0.032));
        //c.addpoint(point2D(0.0192, 0));


        //Caso 3:
        //c.addpoint(point2D(-0.0224, 0.0032));
        //c.addpoint(point2D(-0.0048, -0.0288));
        //c.addpoint(point2D(0.0048, -0.0288));
        //c.addpoint(point2D(0.0224, 0.0032));

        simulacion.addCollector(c, ref);
        std::vector<beam2D> inicios = simulacion.generateBoxBeams(vector2D(-sin(alfa), -cos(alfa)));
        for (int i = 0; i < inicios.size(); i++)
        {
            ray r(inicios[i], simulacion);
        }

        double DCF, DCF_flux, distrib;
        simulacion.calculate(nRayos, DCF, DCF_flux, distrib);
        printf("%f\t%f\t%f\t%f\n", incidencia, DCF, DCF_flux, distrib);
    }
    return 0;
}
int probarCPC(double aceptancia)
{
    for (double incidencia = 0.0; incidencia < 90.0; incidencia += 1.0)
    {
        CircleReactor reactor(point2D(0.0, 0.0), 0.013);
        double DO = 6.68;// / sin(azimuth);
        int nRayos = 500;
        double ref = 0.9;
        simulation simulacion(&reactor, DO, nRayos);
        collector c;
        double alfa = incidencia * M_PI / 180.0;
        


        simulacion.addCollector(c, ref);
        std::vector<beam2D> inicios = simulacion.generateBoxBeams(vector2D(-sin(alfa), -cos(alfa)));
        for (int i = 0; i < inicios.size(); i++)
        {
            ray r(inicios[i], simulacion);
        }

        double DCF, DCF_flux, distrib;
        simulacion.calculate(nRayos, DCF, DCF_flux, distrib);
        printf("%f\t%f\t%f\t%f\n", incidencia, DCF, DCF_flux, distrib);
    }
    return 0;
}
int estudiarSimpl3()
{
    double w = 0.201107692;
    double h = 0.1 + 0.016;// 231261538;
    double r = 0.016;
    double DO = 0.0;
    int nRayos = 30;
    double ref = 0.9;
    CircleReactor reactor(point2D(0.0, 0.0), r);
    double radAnual[] = { 7548.06477361834,7879.15513675877,16341.0006831852,7189.87790349758,19367.7915369513,18766.9120310466,14379.3253152412,27506.6972942494,12992.7058587058,28644.9242480048,16818.9510958296,29004.3004200969,33560.259279401,17469.2059490773,35072.885148497,18993.1250121743,36883.1902942968,22315.2884383293,37334.2007910867,25900.8769567764,37917.8478681086,32450.1406102061,37005.2451141149,45805.2187153237,31806.6645636792,52304.3161298792,43947.7381859982,49048.078476404,32967.8654128444,43595.4674043952,31048.051674083,40421.0881910653,29883.0250101478,37892.8882914824,30303.5379965045,35349.7515366988,30437.048402306,33048.9020494097,31153.0237141262,31505.1114953518,31308.6071936248,28118.7712939108,35324.3029722815,23885.0456996853,33237.9815233796,23720.4553355731,31785.1133009018,23577.8770075995,30231.6478323757,23542.1611274702,28236.4012298353,23816.2157332375,27372.2343137792,23466.8371101563,24744.6447423809,25263.4216771997,21827.3226844367,26335.5520305472,19515.2343641723,24161.8858776575,19972.2002739046,21643.6178288543,24111.5295883932,17122.6670143522,21231.0646368605,18877.5363236552,18151.6788735595,19373.2574553334,19302.6887672491,15932.6508750526,16451.9443975645,17502.8544053314,14834.3144886364,1117.4946290347 };
    double DCF, DCF_flux, distrib;
    double maxAcum = 0.0;
    FILE* writeFile;
    fopen_s(&writeFile, "rayosSimpl3.txt", "w");
    for (int fI = 20; fI < 21; fI++)
    {
        for (int fB = 32; fB < 33; fB++)
        {
            simulation simulacion(&reactor, DO, nRayos);
            collector tramo;
            double f = 0.05 * r * fI;
            double b = 0.05 * r * fB;
            point2D p1(-w/2.0, h-f);
            point2D p2(-b/2.0, -f);
            point2D p3(b/2.0, -f);
            point2D p4(w/2.0, h-f);
            //Calcular si choca p1-p2 con circulo
            vector2D vTramo = p2 - p1;
            vTramo = vTramo / vTramo.mag();
            vector2D v1R = point2D(0, 0) - p1;
            vector2D sombra = vTramo * (v1R & vTramo);
            vTramo = v1R - sombra;
            if (vTramo.mag() < r)
                continue;


            tramo.addpoint(p1);
            tramo.addpoint(p2);
            tramo.addpoint(p3);
            tramo.addpoint(p4);
            simulacion.addCollector(tramo, ref);
            double acum = 0.0;
            for (int index = 50; index < 51; index++)
            {
                double alfa = M_PI * (90 - 40 - index) / 180.0;
                std::vector<beam2D> inicios = simulacion.generateBoxBeams(vector2D(-sin(alfa), -cos(alfa)));
                for (int i = 0; i < inicios.size(); i++)
                {
                    ray r(inicios[i], simulacion);
                    r.draw(writeFile);
                }
                simulacion.calculate(nRayos, DCF, DCF_flux, distrib);
                printf("%d\t%f\t%f\t%f\n", index, DCF, DCF_flux, distrib);
                simulacion.clear();
                acum += DCF * radAnual[index];
            }
            if (acum > maxAcum)
            {
                printf("%d,%d:%g\n", fI, fB, acum);
                maxAcum = acum;
            }
        }
        fclose(writeFile);
    }
    return 0;
}
int probarFresnel()
{
    int incGlobal = 65;
    double reactorDist = 0.15;
    double p_parabola = 0.017;



    double maxAcum = 0.0;
    double initTramos_x = 0.133;
    double initTramos_y = -0.06+0.266*tan(M_PI*incGlobal/180.0);
    double medLongTramos = 0.0133 / cos(M_PI * incGlobal / 180.0);
    double x_centro = -reactorDist * sin(M_PI * incGlobal / 180.0);
    double y_centro = 0.5 * (initTramos_y - 0.06) + reactorDist * cos(M_PI * incGlobal / 180.0);
    if (initTramos_y > 0.249)
    {
        initTramos_y = 0.249;
        medLongTramos = 0.05*0.309 / sin(M_PI * incGlobal / 180.0);
        x_centro = 0.133 - 0.5 * 0.309 / tan(M_PI * incGlobal / 180.0) - reactorDist * sin(M_PI * incGlobal / 180.0);
        y_centro = 0.1545 + reactorDist * cos(M_PI * incGlobal / 180.0);
    }

    printf("%f\t%f\n", x_centro, y_centro);
    FILE* writeFile;
    fopen_s(&writeFile, "rayosFresnel.txt", "w");
    CircleReactor reactor(point2D(x_centro, y_centro), 0.016);
    double DO = 0.0;
    int nRayos = 30;
    double ref = 0.9;
    collector parabola;
    for (int i = 0; i < 321; i++)
    {
        double x_parabola = -2.0 * p_parabola + p_parabola * i / 80.0;
        double y_parabola = x_parabola * x_parabola * 0.25 / p_parabola;
        double rot =  M_PI*(180+incGlobal) / 180.0;
        double x_rot = x_parabola * cos(rot) - y_parabola * sin(rot) + x_centro - p_parabola * sin(M_PI*incGlobal/180.0);
        double y_rot = y_parabola * cos(rot) + x_parabola * sin(rot) + y_centro + p_parabola * cos(M_PI*incGlobal/180.0);
        parabola.addpoint(point2D(x_rot, y_rot));
    }
    double vTramos_x = cos(M_PI * incGlobal / 180.0);;
    double vTramos_y = sin(M_PI * incGlobal / 180.0);
    double radAnual[] = { 7548.06477361834,7879.15513675877,16341.0006831852,7189.87790349758,19367.7915369513,18766.9120310466,14379.3253152412,27506.6972942494,12992.7058587058,28644.9242480048,16818.9510958296,29004.3004200969,33560.259279401,17469.2059490773,35072.885148497,18993.1250121743,36883.1902942968,22315.2884383293,37334.2007910867,25900.8769567764,37917.8478681086,32450.1406102061,37005.2451141149,45805.2187153237,31806.6645636792,52304.3161298792,43947.7381859982,49048.078476404,32967.8654128444,43595.4674043952,31048.051674083,40421.0881910653,29883.0250101478,37892.8882914824,30303.5379965045,35349.7515366988,30437.048402306,33048.9020494097,31153.0237141262,31505.1114953518,31308.6071936248,28118.7712939108,35324.3029722815,23885.0456996853,33237.9815233796,23720.4553355731,31785.1133009018,23577.8770075995,30231.6478323757,23542.1611274702,28236.4012298353,23816.2157332375,27372.2343137792,23466.8371101563,24744.6447423809,25263.4216771997,21827.3226844367,26335.5520305472,19515.2343641723,24161.8858776575,19972.2002739046,21643.6178288543,24111.5295883932,17122.6670143522,21231.0646368605,18877.5363236552,18151.6788735595,19373.2574553334,19302.6887672491,15932.6508750526,16451.9443975645,17502.8544053314,14834.3144886364,1117.4946290347 };
    double DCF, DCF_flux, distrib;
    for (int prueba = 0; prueba < 1; prueba++)
    {
        for (int prueba2 = 0; prueba2 < 1; prueba2++)
        {
            simulation simulacion(&reactor, DO, nRayos);
            simulacion.addCollector(parabola, ref);
            int incTramos[] = { 47,86,37,63,26,20,16,12,9,7 };
            for (int i = 0; i < 10; i++)
            {
                double inc = M_PI * incTramos[i] / 180.0;
                double m = tan(inc);
                double v_mag = sqrt(1.0 + m * m);
                double v_x = 1.0 / v_mag;
                double v_y = m / v_mag;
                double posMedia_x = initTramos_x - medLongTramos * vTramos_x * (2 * i + 1);
                double posMedia_y = initTramos_y - medLongTramos * vTramos_y * (2 * i + 1);
                double pos1_x = posMedia_x + v_x * medLongTramos;
                double pos1_y = posMedia_y + v_y * medLongTramos;
                double pos2_x = posMedia_x - v_x * medLongTramos;
                double pos2_y = posMedia_y - v_y * medLongTramos;
                collector tramo;
                tramo.addpoint(point2D(pos1_x, pos1_y));
                tramo.addpoint(point2D(pos2_x, pos2_y));
                simulacion.addCollector(tramo, ref);
            }
            double acum = 0.0;
            for (int index = 25; index < 26; index++)
            {
                double alfa = M_PI * (90-incGlobal-index) / 180.0;
                std::vector<beam2D> inicios = simulacion.generateBoxBeams(vector2D(-sin(alfa), -cos(alfa)));
                for (int i = 0; i < inicios.size(); i++)
                {
                    ray r(inicios[i], simulacion);
                    r.draw(writeFile);
                }
                simulacion.calculate(nRayos, DCF, DCF_flux, distrib);
                printf("%d\t%f\t%f\t%f\n", index, DCF, DCF_flux, distrib);
                simulacion.clear();
                acum += DCF * radAnual[index];
            }
            if (acum > maxAcum)
            {
                printf("%d,%d:%g\n", prueba, prueba2, acum);
                maxAcum = acum;
            }
        }
    }
    fclose(writeFile);
    return 0;
}
int raceway()
{
    double volume = 0.5;
    int nRayos = 200;
    double lengths[] = { 0.5, 2.0, 3.0, 4.0, 5.0, 6.0 };
    double iniHeights[] = { 0.5, 0.35, 0.29, 0.25, 0.22, 0.20 };
    double slopes[16];
    for (int i = 0; i < 16; i++)
        slopes[i] = M_PI * 5.0 * (3.0 + i) / 180.0;
    double DCF, DCF_flux, distrib;
    double anualRad[] = { 15833.4663355068, 16094.8435328907, 17579.3532243774, 17457.4937626395, 19099.0721623678, 19159.1032935328, 20827.32746471, 20776.4948644954, 22365.0387202248, 22649.7245107518, 24952.3952320825, 24640.680445883, 27201.8550522551, 28663.1496021585, 33520.2977669401, 28901.8717724254, 30016.2033823251, 29421.352908784, 30700.5822045199, 28438.6112504276, 30627.3027207948, 31261.8191415293, 30932.5788734722, 31639.3523421706, 33365.7637495179, 32065.0047778615, 34643.6694283554, 34111.6955938968, 36193.4292949023, 36937.4765562241, 38272.9456578394, 42853.2695887237, 41855.6445737149, 53580.8361029707, 41778.2187333924, 45129.4857118723, 37014.3493977271, 41481.7300105941, 35723.0142357805, 40414.1475436378, 34854.2218552748, 39950.8295679153, 34056.8736156822, 39926.0259902194, 32319.0161279007, 38263.4857295182, 34328.9235268268, 37761.3859341342, 32347.0145995108, 36692.8374383018, 33171.8673002288, 37956.4100798856, 30295.0420633552, 36980.1464159421, 33112.5278811785, 34363.0821264137, 31729.749216495, 37839.3406928627, 28409.9624494966, 36945.0287213153, 29969.9167352393, 35332.1247477481, 30786.0285526814, 34684.2741495175, 29122.655376205, 37444.7152835491, 26193.5629153902, 36750.9627467301, 26926.9610822034, 35465.3656605946, 28185.4528589378, 33957.766394235, 26204.9906048959, 36646.9768752349, 22776.4340498756, 37886.8267935484, 20599.3318645287, 36182.4932237236, 21544.9301624679, 33802.9021591242, 23643.3180582485, 30139.2708542877, 21969.5842055175, 29860.7165180515, 19900.6010820431, 31330.7680817939, 15605.250939202, 28095.6862666047, 15605.250939202, 24681.5913981732 };

    //FILE* writeFile;
    //fopen_s(&writeFile, "racewayPoints.txt", "w");
    double maxAcum = 0.0;
    for (int lengthI = 0; lengthI < 6; lengthI++)
    {
        double length = lengths[lengthI];
        for (int heightFactor = 0; heightFactor < 8; heightFactor++)
        {
            double height = iniHeights[lengthI] * (heightFactor + 1) * 0.25;
            for (int slopeI = 0; slopeI < 16; slopeI++)
            {
                double width = volume / (2.0 * length * height);
                double slopedSide = height * 0.5 * sin(slopes[slopeI]);
                width -= slopedSide;
                //construir geometria
                point2D p2(-width - 0.005, 0.0);
                point2D p0 = p2 + vector2D(-(height + 0.1) * sin(slopes[slopeI]), height + 0.1);
                point2D p1 = p2 + vector2D(-2.0 * slopedSide, height);
                point2D p3(-0.005, 0.0);
                point2D p4(-0.005, height);
                point2D p5(-0.005, height + 0.1);
                point2D p6(0.005, height + 0.1);
                point2D p7(0.005, height);
                point2D p8(0.005, 0.0);
                point2D p9(0.005 + width, 0.0);
                point2D p10 = p7 + (p4 - p1);
                point2D p11 = p6 + (p5 - p0);
                SegmentsReactor r_izq, r_der;
                r_izq.addpoint(p1);
                r_izq.addpoint(p2);
                r_izq.addpoint(p3);
                r_izq.addpoint(p4);
                r_der.addpoint(p7);
                r_der.addpoint(p8);
                r_der.addpoint(p9);
                r_der.addpoint(p10);
                r_izq.close();
                r_der.close();
                r_izq.close();
                r_der.close();
                collector c_izq, c_der;
                c_izq.addpoint(p0);
                c_izq.addpoint(p2);
                c_izq.addpoint(p3);
                c_izq.addpoint(p5);
                c_der.addpoint(p6);
                c_der.addpoint(p8);
                c_der.addpoint(p9);
                c_der.addpoint(p11);
                //Crear caso:
                simulation simulacion(&r_izq, 0.0, nRayos);
                simulacion.addReactor(&r_der);
                simulacion.addCollector(c_izq, 0.7);
                simulacion.addCollector(c_der, 0.7);
                double acum = 0.0;
                for (int inci = 0; inci < 90; inci++)
                {
                    double alfa = M_PI * inci / 180.0;
                    std::vector<beam2D> inicios = simulacion.generateBoxBeams(vector2D(-sin(alfa), -cos(alfa)));
                    for (int i = 0; i < inicios.size(); i++)
                    {
                        ray r(inicios[i], simulacion);
                    }
                    simulacion.calculate(nRayos, DCF, DCF_flux, distrib);
                    acum += anualRad[inci] * DCF;
                    //printf("%d\t%f\t%f\t%f\n", inci, DCF, DCF_flux, distrib);
                    simulacion.clear();
                }
                acum *= height;
                if (acum > maxAcum)
                {
                    maxAcum = acum;
                    printf("%f\t%f\t%f\t%d\t%f\n", length, height, width, slopeI * 5, acum/height);
                }
            }
        }
    }
    return 0;
}