#include "ray.h"

ray::ray(beam2D h, simulation& c)
	: spent_(false)
{
	travel.push_back(h);
	double dist = 0.0;
	double energy = 1.0;
	int index = -1;
	while (dist < 1e20 && energy>1e-6 && travel.size() < 500) {
		dist = 1e20;
		c.check(travel, dist, energy, spent_, index);
	}
}
size_t ray::size()
{
	return travel.size();
}
void ray::draw(FILE * f)
{
	for (int i = 0; i < travel.size(); i++)
	{
		fprintf(f, "%f\t%f\t\t%f\t%f\n", travel[i].origin().x(), travel[i].origin().y(), travel[i].direction().x(), travel[i].direction().y());
	}
}
void ray::drawX()
{
	printf("%f", travel[0].origin().x());
	for (int i = 1; i < travel.size(); i++)
	{
		printf(", %f", travel[i].origin().x());
	}
}

void ray::drawY()
{
	printf("%f", travel[0].origin().y());
	for (int i = 1; i < travel.size(); i++)
	{
		printf(", %f", travel[i].origin().y());
	}
}
