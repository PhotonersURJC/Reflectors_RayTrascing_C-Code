#include "point3D.h"

point3D::point3D(double x, double y, double z) :x_(x), y_(y), z_(z) {}

point3D::point3D() :x_(0.0), y_(0.0), z_(0.0) {}

vector3D point3D::operator-(const point3D& p) const
{
	return vector3D(x_ - p.x_, y_ - p.y_, z_ - p.z_);
}

point3D point3D::operator+(const vector3D& v) const
{
	return point3D(x_ + v.x(), y_ + v.y(), z_+v.z());
}

point3D point3D::operator-(const vector3D& v) const
{
	return point3D(x_ - v.x(), y_ - v.y(), z_ - v.z());
}

void point3D::draw()
{
	printf("%f\t%f\t%f\n", x_, y_, z_);
}