#pragma once

#include <cmath>
#include <vector>
# define M_PI          3.141592653589793238462643383279502884L

class vector2D
{
	double x_;
	double y_;
public:
	vector2D(double x, double y) :x_(x), y_(y) {}

	double x() const { return x_; }
	double y() const { return y_; }
	double mag() const { return sqrt(x_ * x_ + y_ * y_); }

	vector2D& operator=(const vector2D& v);
	vector2D& operator+=(const vector2D& v);
	vector2D& operator-=(const vector2D& v);
	vector2D& operator*=(const double s);
	vector2D& operator/=(const double s);
	vector2D operator+(vector2D v) const;
	vector2D operator-(vector2D v) const;
	vector2D operator*(const double s) const;
	vector2D operator/(const double s) const;

	//Scalar Product
	double operator&(const vector2D& v) const;

	//Cross product
	double operator^(const vector2D& v) const;
};

