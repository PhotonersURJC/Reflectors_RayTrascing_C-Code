#pragma once
#include "simulation.h"
class ray
{
	std::vector<beam2D> travel;
	bool spent_;
public:
	ray(beam2D h, simulation& c);
	void draw(FILE * f);
	void drawX();
	void drawY();
	size_t size();
};

