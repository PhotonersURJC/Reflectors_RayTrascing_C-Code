#pragma once

#include "beam2D.h"

class segment
{
	const point2D& p1_; //Can be stored as references, collectors will use a list of points
	const point2D& p2_;
	double l_;
public:
	segment();
	segment(const point2D& p1, const point2D& p2);
	bool check(beam2D h, std::vector<point2D>& collisions, double& dist, double& reactorLength, vector2D& newDir, int& lastIndex, int& bounceCounter);
};

