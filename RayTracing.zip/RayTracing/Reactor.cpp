#include "Reactor.h"

Reactor::Reactor() : contrib_DCF(0.0), contrib_flux(0.0) {}

void Reactor::clearContribs()
{
	contrib_DCF = 0.0;
	contrib_flux = 0.0;
	for (int i = 0; i < 360; i++)
		contrib_locs[i] = 0.0;
}

void Reactor::calculate(int nRayos, double& DCF, double& DCF_flux, double& distrib, double& area)
{
	//printf("%f\n", contrib_DCF / (M_PI * radio_ * radio_));
	//printf("DCF_flux: %f\n", contrib_flujo / nRayos);
	DCF_flux += contrib_flux / nRayos;
	double contribDesvEst = 0.0;
	double contribMedia = 0.0;
	for (int i = 0; i < 360; i++)
		contribMedia += contrib_locs[i];
	contribMedia /= 360.0;
	for (int i = 0; i < 360; i++)
		contribDesvEst += (contrib_locs[i] - contribMedia)* (contrib_locs[i] - contribMedia) /360.0;
	distrib += sqrt(contribDesvEst);
	DCF += contrib_DCF;
	area += this->getArea();
}
