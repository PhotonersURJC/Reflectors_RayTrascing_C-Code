#include "segment.h"

segment::segment() :p1_(point2D::nullPoint), p2_(point2D::nullPoint), l_(0.0) {}

segment::segment(const point2D& p1, const point2D& p2) :p1_(p1), p2_(p2) { l_ = (p2 - p1).mag(); }

bool segment::check(beam2D h, std::vector<point2D>& collisions, double& dist, double& reactorLength, vector2D& newDir, int& lastIndex, int& bouncesCounter)
{
	bouncesCounter++;
	if (lastIndex == bouncesCounter) //discards a beam travelling from a segment to the same segment
		return false;
	double a = h.origin().y() - p1_.y();
	double b = h.origin().x() - p1_.x();
	double dirX = h.direction().x();
	double dirY = h.direction().y();
	vector2D v = p2_ - p1_;
	v = v / v.mag();
	double lengthToHit = (dirX * a - dirY * b) / (dirX * v.y() - dirY * v.x());
	if ((lengthToHit > l_) || (lengthToHit <0.0))
		return false;
	point2D collisionPoint = p1_ + v * lengthToHit;
	double t1 = (collisionPoint - h.origin()) & h.direction();
	if (t1 < 0.0)
		return false;
	double dist2 = (collisionPoint - h.origin()).mag();
	if (dist2 < 0.0) 
		return false;
	if (dist2 < dist)
	{
		collisions.clear();
		collisions.push_back(collisionPoint);
		reactorLength = 0.0;
		dist = dist2;
		newDir = v * 2.0 * (h.direction() & v);
		newDir = newDir-h.direction();
		lastIndex = bouncesCounter;
		return true;
	}
	return false;
}
