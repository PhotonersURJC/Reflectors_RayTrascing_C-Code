#pragma once

#include "vector3D.h"

class point3D
{
	double x_;
	double y_;
	double z_;
public:
	point3D(double x, double y, double z);
	point3D();
	double x() const { return x_; }
	double y() const { return y_; }
	double z() const { return z_; }
	static point3D nulo;

	vector3D operator-(const point3D& p) const;
	point3D operator+(const vector3D& v) const;
	point3D operator-(const vector3D& v) const;
	void draw();
};

