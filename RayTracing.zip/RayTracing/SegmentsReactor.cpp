#include "SegmentsReactor.h"

void SegmentsReactor::addpoint(point2D p)
{
	points_.push_back(p);
}

void SegmentsReactor::close()
{
	for (int i = 1; i < points_.size(); i++)
		segments_.push_back(segment(points_[i - 1], points_[i]));
	if (points_.size() > 2)
	{
		segment t(points_[points_.size() - 1], points_[0]);
		segments_.push_back(t);

		//FUTURE WORK: Adaptar to concave geometries
		//To calculate area, trangles are generated from point index 0 to the remaining ones
		//If N points, First triangle: 0 1 2, Last triangle: 0 N-2 N-1
		area_ = 0.0;
		for (int i = 2; i < points_.size(); i++)
		{
			const double& x1 = points_[0].x();
			const double& x2 = points_[i-1].x();
			const double& x3 = points_[i].x();
			const double& y1 = points_[0].y();
			const double& y2 = points_[i-1].y();
			const double& y3 = points_[i].y();
			area_ += 0.5 * abs(x1 * (y2-y3) + x2 * (y3-y1) + x3 * (y1-y2));
		}
	}
}

double SegmentsReactor::getMainLength()
{
	return 1.0; //Use DO = absorptionCoeff right now
}
double SegmentsReactor::getArea()
{
	return area_;
}

void SegmentsReactor::addContribs(double DCF, double flux, point2D colPoint)
{
	contrib_DCF += DCF;
	contrib_flux += flux;
}
bool SegmentsReactor::check(beam2D h, std::vector<point2D>& collisions, double& dist, double& reactorLength, vector2D& newDir, int& lastIndex, int& bouncesCounter)
{
	bool hits = false;
	//oldDir is stored because reactor limits should be transparent (no refraction is considered)
	vector2D oldDir = h.direction();
	double currentRL = 1e20;
	int temp1 = lastIndex;
	int temp2 = bouncesCounter;
	std::vector<point2D> currentCol;
	for (int i = 0; i < segments_.size(); i++)
	{
		if (segments_[i].check(h, collisions, dist, reactorLength, newDir, lastIndex, bouncesCounter))
		{
			hits = true;
			temp1 = lastIndex;
			temp2 = bouncesCounter;
			beam2D h2(collisions[0], oldDir);
			//colisiones has the collision point inside
			for (int j = 0; j < segments_.size(); j++)
			{
				if (i == j) continue;
				segments_[j].check(h2, currentCol, currentRL, reactorLength, newDir, temp1, temp2);
				//h2 remains constant, currentCol stores the new points, but will change them until minimum currrentRL
			}
		}
	}
	if (hits && currentCol.size())
	{
		collisions.push_back(currentCol[0]); //two positions
		lastIndex = temp2;
		reactorLength = currentRL;
		newDir = oldDir;
		return true;
	}
	return false;
}
void SegmentsReactor::box(double& minX, double& maxX, double& minY, double& maxY)
{
	minX = points_[0].x();
	maxX = points_[0].x();
	minY = points_[0].y();
	maxY = points_[0].y();
	for (int i = 1; i < points_.size(); i++)
	{
		minX = (points_[i].x() < minX) ? points_[i].x() : minX;
		maxX = (points_[i].x() > maxX) ? points_[i].x() : maxX;
		minY = (points_[i].y() < minY) ? points_[i].y() : minY;
		maxY = (points_[i].y() > maxY) ? points_[i].y() : maxY;
	}
}
void SegmentsReactor::updateBox(double& minX, double& maxX, double& minY, double& maxY)
{
	for (int i = 0; i < points_.size(); i++)
	{
		minX = (points_[i].x() < minX) ? points_[i].x() : minX;
		maxX = (points_[i].x() > maxX) ? points_[i].x() : maxX;
		minY = (points_[i].y() < minY) ? points_[i].y() : minY;
		maxY = (points_[i].y() > maxY) ? points_[i].y() : maxY;
	}
}