#pragma once
#include "point2D.h"
class beam2D
{
	point2D origin_;
	vector2D direction_; //unitary vector
	double energy_;
public:
	beam2D(point2D origin, vector2D direction) : origin_(origin), direction_(direction / direction.mag()), energy_(1.0){}
	beam2D(point2D origin, vector2D direction, double energy) : origin_(origin), direction_(direction / direction.mag()), energy_(energy){}

	const point2D origin() const{
		return origin_;
	}
	const vector2D direction() const {
		return direction_;
	}
	double getEnergy() const { return energy_; }
	void setEnergy(double energy) { energy_ = energy; }
};

