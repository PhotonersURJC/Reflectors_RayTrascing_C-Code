#pragma once
#include "collector.h"
class simulation
{
	std::vector<collector> collectors;
	std::vector<double> reflectances;
	std::vector<Reactor *> reactors;
	double absorptionCoeff;
	int nRays_;
	double incidentRadiation;
	double delta_;
public:
	simulation(Reactor * reactor, double OD, int nRayos);
	void addCollector(collector c, double reflectancia);
	void addReactor(Reactor * reactor);
	void calculate(int nRays, double& DCF, double& DCF_flux, double& distrib);
	void clear();
	//This check function returns beam whole travel and calculates its energy after it
	void check(std::vector<beam2D>& travel, double& dist, double& energy, bool& spent, int& lastIndex);
	std::vector<beam2D> generateBoxBeams(vector2D direction);
	void draw();
};

