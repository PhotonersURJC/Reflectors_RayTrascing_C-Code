#pragma once
#include "CircleReactor.h"
class SegmentsReactor : public Reactor
{
	double area_;
	std::vector<point2D> points_;
	std::vector<segment> segments_;
public:
	SegmentsReactor() :points_(0), segments_(0), area_(0.0) {}
	void addpoint(point2D p);
	void close();
	virtual double getMainLength();
	virtual double getArea();

	virtual void addContribs(double DCF, double flux, point2D colPoint);
	virtual bool check(beam2D h, std::vector<point2D>& collisions, double& dist, double& reactorLength, vector2D& newDir, int& lastIndex, int& bouncesCounter);
	virtual void box(double& minX, double& maxX, double& minY, double& maxY);
	virtual void updateBox(double& minX, double& maxX, double& minY, double& maxY);
};

