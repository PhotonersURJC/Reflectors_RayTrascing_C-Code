#pragma once

#include "vector2D.h"

class vector3D
{
	double x_;
	double y_;
	double z_;
public:
	vector3D(double x, double y, double z) :x_(x), y_(y), z_(z) {}

	double x() const { return x_; }
	double y() const { return y_; }
	double z() const { return z_; }
	double mag() const { return sqrt(x_ * x_ + y_ * y_ + z_*z_); }

	vector3D& operator=(const vector3D& v);
	vector3D& operator+=(const vector3D& v);
	vector3D& operator-=(const vector3D& v);
	vector3D& operator*=(const double s);
	vector3D& operator/=(const double s);
	vector3D operator+(vector3D v) const;
	vector3D operator-(vector3D v) const;
	vector3D operator*(const double s) const;
	vector3D operator/(const double s) const;

	//Scalar Product:
	double operator&(const vector3D& v) const;

	//Cross product:
	vector3D operator^(const vector3D& v) const;
};

