#pragma once

#include "vector2D.h"

class point2D
{
	double x_;
	double y_;
public:
	point2D(double x, double y);
	point2D();
	double x() const { return x_; }
	double y() const { return y_; }
	static point2D nullPoint;

	vector2D operator-(const point2D& p) const;
	point2D operator+(const vector2D& v) const;
	point2D operator-(const vector2D& v) const;
	void draw();
};

