#include "simulation.h"

simulation::simulation(Reactor * reactor, double OD, int nRays)
	: reactors(1, reactor),
	absorptionCoeff(OD / 2.0 / reactor->getMainLength()),
	nRays_(nRays),
	incidentRadiation(0.0),
	delta_(0.0)
{}

void simulation::addCollector(collector c, double reflectance)
{
	collectors.push_back(c);
	collectors.back().createSegments();
	reflectances.push_back(reflectance);
}

void simulation::addReactor(Reactor * reactor)
{
	reactors.push_back(reactor);
}

void simulation::clear()
{
	for (int i = 0; i < reactors.size(); i++)
		reactors[i]->clearContribs();
}

void simulation::calculate(int nRays, double& DCF, double& DCF_flux, double& distrib)
{
	DCF = 0.0;
	DCF_flux = 0.0;
	distrib = 0.0;
	double area = 0.0;
	for (int i = 0; i < reactors.size(); i++)
		reactors[i]->calculate(nRays, DCF, DCF_flux, distrib,area);
	DCF /= area;
}

//This check function returns beam whole travel and calculates its energy after it
//lastIndex is the last element index the beam impacted (-1 if new)
//Every simple object (circle/segment) adds 1 to bouncesCounter and 1 to index
//The counter is created here, as there will be a single case
void simulation::check(std::vector<beam2D>& travel, double& dist, double& energy, bool& spent, int& lastIndex)
{
	beam2D h = travel.back();
	double reactorLength = 0.0;
	std::vector<point2D> collisions;
	vector2D nuevaDir(0.0, 0.0);
	double reflectance = 0.0;
	int reactorIndex = -1;
	int bouncesCounter = 0;
	for (int i = 0; i < collectors.size(); i++) {
		if (collectors[i].check(h, collisions, dist, reactorLength, nuevaDir, lastIndex, bouncesCounter))
			reflectance = reflectances[i];
	}
	for (int i = 0; i < reactors.size(); i++) {
		if (reactors[i]->check(h, collisions, dist, reactorLength, nuevaDir, lastIndex, bouncesCounter)) {
			reactorIndex = i;
		}
	}
	energy = h.getEnergy();
	if (reactorLength>1.0e-6)
	{
		//Nearest collision with reactor
		double flux = 0.0;
		if (!spent)
		{
			spent = true;
			flux = energy;
		}
		if (absorptionCoeff < 1.e-6) //transparent
		{
			reactors[reactorIndex]->addContribs(reactorLength * delta_ * energy, flux, collisions[0]);
			travel.push_back(beam2D(collisions[0], nuevaDir, energy));
			travel.push_back(beam2D(collisions[1], nuevaDir, energy));
			//energia no cambia
			return;
		}
		reactors[reactorIndex]->addContribs(delta_ * energy * (1 - exp(-absorptionCoeff * reactorLength)) / absorptionCoeff, flux, collisions[0]);
		energy = energy * exp(-absorptionCoeff * reactorLength);
		travel.push_back(beam2D(collisions[0], nuevaDir, energy));
		travel.push_back(beam2D(collisions[1], nuevaDir, energy));
		return;
	}
	if (collisions.size()) {
		energy = reflectance * energy;
		travel.push_back(beam2D(collisions[0], nuevaDir, energy));
	}
}

std::vector<beam2D> simulation::generateBoxBeams(vector2D direction)
{
	double minX, maxX, minY, maxY, emissionLength, deltaY, deltaX;
	reactors[0]->box(minX, maxX, minY, maxY);
	for(int i = 1; i < reactors.size(); i++)
		reactors[i]->updateBox(minX, maxX, minY, maxY);
	minX *= 1.1;
	maxX *= 1.1;
	minY *= 1.1;
	maxY *= 1.1;
	for (int i = 0; i < collectors.size(); i++)
		collectors[i].box(minX, maxX, minY, maxY);
	std::vector<beam2D> res;
	direction = direction / direction.mag();
	//Base case: Horizontal emission
	if (direction.y() == 0)
	{
		emissionLength = maxY - minY;
		deltaY = emissionLength / nRays_;
		double y = minY + deltaY * 0.5;
		delta_ = deltaY;
		for (int i = 0; i < nRays_; i++)
		{
			if (direction.x() > 0.0)
				res.push_back(beam2D(point2D(minX, y), direction));
			else
				res.push_back(beam2D(point2D(maxX, y), direction));
			y += deltaY;
		}
		return res;
	}
	//Base case: vertical emission
	if (direction.x() == 0)
	{
		emissionLength = maxX - minX;
		deltaX = emissionLength / nRays_;
		delta_ = deltaX;
		double x = minX + deltaX * 0.5;
		for (int i = 0; i < nRays_; i++)
		{
			if (direction.y() > 0.0)
				res.push_back(beam2D(point2D(x, minY), direction));
			else
				res.push_back(beam2D(point2D(x, maxY), direction));
			x += deltaX;
		}
		return res;
	}
	//general case:
	emissionLength = (maxY - minY) * abs(direction.x()) + (maxX - minX) * abs(direction.y());
	delta_ = emissionLength / nRays_;
	deltaY = delta_ / abs(direction.x());
	deltaX = delta_ / abs(direction.y());
	int nRaysY = static_cast<int>(floor(0.5 + (maxY - minY) / deltaY));
	//only half a beam needs to fit, not its whole width
	int nRaysX = nRays_ - nRaysY;
	//From left
	if (direction.x() > 0)
	{
		//From down left
		if (direction.y() > 0)
		{
			double y = maxY - 0.5 * deltaY;
			for (int i = 0; i < nRaysY; i++)
			{
				res.push_back(beam2D(point2D(minX, y), direction));
				y -= deltaY;
			}
			double remaining = (y - minY) * direction.x();
			remaining = (emissionLength / nRays_ - remaining) / direction.y();
			double x = minX + remaining;
			for (int i = 0; i < nRaysX; i++)
			{
				res.push_back(beam2D(point2D(x, minY), direction));
				x += deltaX;
			}
			return res;
		}
		//From up left
		double y = minY + 0.5 * deltaY;
		for (int i = 0; i < nRaysY; i++)
		{
			res.push_back(beam2D(point2D(minX, y), direction));
			y += deltaY;
		}
		double remaining = (maxY - y) * direction.x();
		remaining = (remaining - emissionLength / nRays_) / direction.y(); //Substract terms swapped, as d.y() is negative
		double x = minX + remaining;
		for (int i = 0; i < nRaysX; i++)
		{
			res.push_back(beam2D(point2D(x, maxY), direction));
			x += deltaX;
		}
		return res;
	}
	//From right
	//From down right
	if (direction.y() > 0)
	{
		double y = maxY - 0.5 * deltaY;
		for (int i = 0; i < nRaysY; i++)
		{
			res.push_back(beam2D(point2D(maxX, y), direction));
			y -= deltaY;
		}
		double remaining = (minY - y) * direction.x();//same reason to swap terms
		remaining = (emissionLength / nRays_ - remaining) / direction.y();
		double x = maxX - remaining;
		for (int i = 0; i < nRaysX; i++)
		{
			res.push_back(beam2D(point2D(x, minY), direction));
			x -= deltaX;
		}
		return res;
	}
	//From up right
	double y = minY + 0.5 * deltaY;
	for (int i = 0; i < nRaysY; i++)
	{
		res.push_back(beam2D(point2D(maxX, y), direction));
		y += deltaY;
	}
	double remaining = (y - maxY) * direction.x();
	remaining = (remaining - emissionLength / nRays_) / direction.y(); //both substract terms swapped
	double x = maxX - remaining;
	for (int i = 0; i < nRaysX; i++)
	{
		res.push_back(beam2D(point2D(x, maxY), direction));
		x -= deltaX;
	}
	return res;
}

void simulation::draw()
{
	for (int i = 0; i < collectors.size(); i++)
		collectors[i].draw();
}
