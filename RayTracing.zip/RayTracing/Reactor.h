#pragma once

#include "segment.h"

class Reactor
{
protected:
	double contrib_locs[360];
	double contrib_DCF;
	double contrib_flux;
public:
	
	Reactor();
	
	void clearContribs();
	void calculate(int nRayos, double& DCF, double& DCF_flux, double& distrib, double& area);


	virtual double getArea() = 0;
	virtual double getMainLength() = 0;
	virtual void addContribs(double DCF, double flux, point2D colPoint) = 0;
	//Checks for collisions. If new disttance is shorter than the stored one, swaps them and stores the points. Returns the new direction
	virtual bool check(beam2D h, std::vector<point2D>& collisions, double& dist, double& reactorLength, vector2D& newDir, int& lastIndex, int& bouncesCounter) = 0;
	virtual void box(double& minX, double& maxX, double& minY, double& maxY) = 0;
	virtual void updateBox(double& minX, double& maxX, double& minY, double& maxY) = 0;
};

