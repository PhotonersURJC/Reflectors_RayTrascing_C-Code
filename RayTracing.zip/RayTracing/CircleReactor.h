#pragma once
#include "Reactor.h"
class CircleReactor : public Reactor
{
	point2D center_;
	double radius_;
public:
	CircleReactor(point2D center, double radius);
	CircleReactor();
	virtual double getMainLength() { return radius_; }
	virtual double getArea() { return M_PI * radius_ * radius_; }

	virtual void addContribs(double DCF, double flux, point2D colPoint);
	virtual bool check(beam2D h, std::vector<point2D>& collisions, double& dist, double& reactorLength, vector2D& newDir, int& lastIndex, int& bouncesCounter);
	virtual void box(double& minX, double& maxX, double& minY, double& maxY);
	virtual void updateBox(double& minX, double& maxX, double& minY, double& maxY);
};

