#include "CircleReactor.h"

CircleReactor::CircleReactor(point2D center, double radius) :center_(center), radius_(radius)
{
	for (int i = 0; i < 360; i++)
		contrib_locs[i] = 0.0;
}
CircleReactor::CircleReactor() :center_(), radius_(0.0)
{
	for (int i = 0; i < 360; i++)
		contrib_locs[i] = 0.0;
}
void CircleReactor::addContribs(double DCF, double flux, point2D colPos)
{
	contrib_DCF += DCF;
	contrib_flux += flux;
	vector2D vR = (colPos - center_) / radius_;
	double alpha = acos(vR.x());
	if (vR.y() < 0.0)
		alpha = 2 * M_PI - alpha;
	contrib_locs[(int)(alpha * 180.0 / M_PI)] += flux;
}
bool CircleReactor::check(beam2D h, std::vector<point2D>& collisions, double& dist, double& reactorLength, vector2D& newDir, int& lastIndex, int& bouncesCounter)
{
	bouncesCounter++;
	if (lastIndex == bouncesCounter)
		return false;
	double pDist = (h.origin() - center_).mag();
	double shadowLength = h.direction() & (center_ - h.origin());
	vector2D shadowVector = h.direction() * shadowLength;
	point2D nearPoint = h.origin() + shadowVector;
	double dist2 = (nearPoint - center_).mag();
	if (dist2 < radius_)
	{
		double halfWay = sqrt(radius_ * radius_ - dist2 * dist2);
		shadowLength -= halfWay;
		if (shadowLength > 0.0)
			if (shadowLength < dist)
			{
				collisions.clear();
				collisions.push_back(nearPoint - h.direction() * halfWay);
				collisions.push_back(nearPoint + h.direction() * halfWay);
				reactorLength = halfWay * 2.0;
				dist = shadowLength;
				newDir = h.direction();
				lastIndex = bouncesCounter;
				return true;
			}
	}
	return false;
}
void CircleReactor::box(double& minX, double& maxX, double& minY, double& maxY)
{
	minX = center_.x() - radius_;
	maxX = center_.x() + radius_;
	minY = center_.y() - radius_;
	maxY = center_.y() + radius_;
}
void CircleReactor::updateBox(double& minX, double& maxX, double& minY, double& maxY)
{
	minX = (center_.x() - radius_) < minX ? (center_.x() - radius_) : minX;
	maxX = (center_.x() + radius_) > maxX ? (center_.x() + radius_) : maxX;
	minY = (center_.y() - radius_) < minY ? (center_.y() - radius_) : minY;
	maxY = (center_.y() + radius_) > maxY ? (center_.y() + radius_) : maxY;
}
