#include "collector.h"

void collector::addpoint(point2D p)
{
	points_.push_back(p);
}
void collector::createSegments()
{
	for (int i = 1; i < points_.size(); i++)
		segments_.push_back(segment(points_[i - 1], points_[i]));
}

void collector::close()
{
	if (points_.size() > 2)
	{
		segment t(points_[points_.size() - 1], points_[0]);
		segments_.push_back(t);
	}
}

bool collector::check(beam2D h, std::vector<point2D>& collisions, double& dist, double& reactorLength, vector2D& newDir, int& lastIndex, int& bouncesCounter)
{
	bool hits = false;
	for (int i = 0; i < segments_.size(); i++)
		if (segments_[i].check(h, collisions, dist, reactorLength, newDir, lastIndex, bouncesCounter))
			hits = true;
	return hits;
}

void collector::box(double& minX, double& maxX, double& minY, double& maxY)
{
	for (int i = 0; i < points_.size(); i++)
	{
		minX = (points_[i].x() < minX) ? points_[i].x() : minX;
		maxX = (points_[i].x() > maxX) ? points_[i].x() : maxX;
		minY = (points_[i].y() < minY) ? points_[i].y() : minY;
		maxY = (points_[i].y() > maxY) ? points_[i].y() : maxY;
	}
}

void collector::draw()
{
	for (int i = 0; i < points_.size(); i++)
		points_[i].draw();
	printf("\n");
}
