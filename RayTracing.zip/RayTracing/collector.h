#pragma once
#include  "SegmentsReactor.h"
class collector
{
	std::vector<point2D> points_;
	std::vector<segment> segments_;
public:
	collector():points_(0),segments_(0){}
	
	void addpoint(point2D p);
	void close();
	void createSegments();
	bool check(beam2D h, std::vector<point2D>& collisions, double& dist, double& reactorLength, vector2D& newDir, int& lastIndex, int& bouncesCounter);
	void box(double& minX, double& maxX, double& minY, double& maxY);
	void draw();
};

