#include "vector3D.h"

vector3D& vector3D::operator=(const vector3D& v)
{
	x_ = v.x_;
	y_ = v.y_;
	z_ = v.z_;
	return *this;
}

vector3D& vector3D::operator+=(const vector3D& v)
{
	x_ += v.x_;
	y_ += v.y_;
	z_ += v.z_;
	return *this;
}

vector3D& vector3D::operator-=(const vector3D& v)
{
	x_ -= v.x_;
	y_ -= v.y_;
	z_ -= v.z_;
	return *this;
}

vector3D& vector3D::operator*=(const double s)
{
	x_ *= s;
	y_ *= s;
	z_ *= s;
	return *this;
}

vector3D& vector3D::operator/=(const double s)
{
	x_ /= s;
	y_ /= s;
	z_ /= s;
	return *this;
}

vector3D vector3D::operator+(vector3D v) const
{
	v += *this;
	return v;
}

vector3D vector3D::operator-(vector3D v) const
{
	v.x_ = x_ - v.x_;
	v.y_ = y_ - v.y_;
	v.z_ = z_ - v.z_;
	return v;
}

vector3D vector3D::operator*(const double s) const
{
	return vector3D(x_ * s, y_ * s, z_*s);
}

vector3D vector3D::operator/(const double s) const
{
	return vector3D(x_ / s, y_ / s, z_/s);
}

//Scalar Product
double vector3D::operator&(const vector3D& v) const
{
	return x_ * v.x_ + y_ * v.y_ + z_*v.z_;
}

//Cross Product
vector3D vector3D::operator^(const vector3D& v) const
{
	return vector3D
	(
		y_ * v.z_ - v.y_ * z_,
		v.x_ * z_ - x_ * v.z_,
		x_ * v.y_ - v.x_ * y_
	);
}
