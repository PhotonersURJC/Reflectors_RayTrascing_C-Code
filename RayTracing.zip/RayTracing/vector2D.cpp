#include "vector2D.h"

vector2D& vector2D::operator=(const vector2D& v)
{
	x_ = v.x_;
	y_ = v.y_;
	return *this;
}

vector2D& vector2D::operator+=(const vector2D& v)
{
	x_ += v.x_;
	y_ += v.y_;
	return *this;
}

vector2D& vector2D::operator-=(const vector2D& v)
{
	x_ -= v.x_;
	y_ -= v.y_;
	return *this;
}

vector2D& vector2D::operator*=(const double s)
{
	x_ *= s;
	y_ *= s;
	return *this;
}

vector2D& vector2D::operator/=(const double s)
{
	x_ /= s;
	y_ /= s;
	return *this;
}

vector2D vector2D::operator+(vector2D v) const
{
	v += *this;
	return v;
}

vector2D vector2D::operator-(vector2D v) const
{
	v.x_ = x_ - v.x_;
	v.y_ = y_ - v.y_;
	return v;
}

vector2D vector2D::operator*(const double s) const
{
	return vector2D(x_ * s, y_ * s);
}

vector2D vector2D::operator/(const double s) const
{
	return vector2D(x_ / s, y_ / s);
}

//Scalar product
double vector2D::operator&(const vector2D& v) const
{
	return x_ * v.x_ + y_ * v.y_;
}

//2D version of cross product: The result is the normal coordinate value
double vector2D::operator^(const vector2D& v) const
{
	return x_ * v.y_ - y_ * v.x_;
}
